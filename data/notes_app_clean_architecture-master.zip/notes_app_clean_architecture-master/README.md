This project was made following the instructions of the amazing Android Developer
Philipp Lackner on his YouTube channel, he has amazing videos about Android
Development, so I really recommend you subscribe on his channel. This app is an
example of how to use Clean Architecture, MVVM, JetPack Compose, ViewModel, Flow,
Coroutines, Room, Navigation, Dependency Injection with Dagger Hilt and I updated the app to
use Material Design 3.

![Screenshot_20221214-104202_Note App](https://user-images.githubusercontent.com/641469/207619695-2fda0229-b995-4e2d-b3e4-5c41e7297a24.jpeg)


![Screenshot_20221214-104252_Note App](https://user-images.githubusercontent.com/641469/207619741-8b0ec161-f6cd-4999-b691-e958b901902a.jpeg)


![Screenshot_20221214-104306_Note App](https://user-images.githubusercontent.com/641469/207619781-b1f2787a-e3e2-4b47-8d88-c0c7f00f63b0.jpeg)


![Screenshot_20221214-104456_Note App](https://user-images.githubusercontent.com/641469/207619796-93d5c723-a33c-4e66-9442-82c20bb772bc.jpeg)
