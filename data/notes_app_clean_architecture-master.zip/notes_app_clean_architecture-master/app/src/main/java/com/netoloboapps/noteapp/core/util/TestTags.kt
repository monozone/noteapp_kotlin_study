package com.netoloboapps.noteapp.core.util

object TestTags {
    const val ORDER_SECTION = "ORDER_SECTION"
    const val TITLE_TEXT_FIELD = "TITLE_TEXT_FIELD"
    const val CONTENT_TEXT_FIELD = "CONTENT_TEXT_FIELD"
    const val NOTE_ITEM = "NOTE_ITEM"
}